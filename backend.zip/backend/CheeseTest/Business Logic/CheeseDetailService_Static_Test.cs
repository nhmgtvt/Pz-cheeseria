﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pz.Cheeseria.Api.Business_Logic;
using Pz.Cheeseria.Api.Data;
using Pz.Cheeseria.Api.Models;

namespace CheeseTest
{
    [TestClass]
    public class CheeseDetailService_Static_Test
    {

        [TestMethod]
        public void TestGetCheeseById()
        {
            // test if CheeseDetailService_Static return result with error in case reading failed;

            // Arrange
            var repo = new CheeseRepo();
            int id = 1;
            var testCheeseDetailService_Static = new CheeseDetailService_Static(repo);

            // Act
            GetCheeseResult actualResult = testCheeseDetailService_Static.GetCheeseDetailById(id);

            // Assert
            Assert.IsNotNull(actualResult.Error);
        }
        private class CheeseRepo : ICheeseRepo
        {
            public Cheese GetCheeseById(int Id)
            {
                throw new System.NotImplementedException();
            }
        }
    }
}
