using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pz.Cheeseria.Api.Data;
using Pz.Cheeseria.Api.Models;

namespace CheeseTest
{
    [TestClass]
    public class CheeseRepo_Static_Test
    {
        
        [TestMethod]
        public void TestGetCheeseById()
        {
            // test if GetCheeseById return correctly;

            // Arrange
            int id = 1;
            var testCheeseRepo_Static  = new CheeseRepo_Static();

            // Act
            string actualTitle = testCheeseRepo_Static.GetCheeseById(id).Title;

            // Assert
            string expectedTitle = "ABBAYE DE BELLOC";
            Assert.AreEqual(expectedTitle, actualTitle);
        }
    }
}
