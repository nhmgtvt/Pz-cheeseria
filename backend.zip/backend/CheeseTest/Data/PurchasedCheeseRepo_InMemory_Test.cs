﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pz.Cheeseria.Api.Data;
using Pz.Cheeseria.Api.Models;

namespace CheeseTest
{
    [TestClass]
    public class PurchasedCheeseRepo_InMemory_Test
    {
        
        [TestMethod]
        public void TestSavePurchasedCheeses()
        {
            // test if SavePurchasedCheeses return right number of saved object;

            // Arrange
            var purchasedCheese1 = new PurchasedCheese();
            var purchasedCheese2 = new PurchasedCheese();
            var testList = new List<PurchasedCheese>();
            testList.Add(purchasedCheese1);
            testList.Add(purchasedCheese2);
            var purchasedCheeseRepo_InMemory = new PurchasedCheeseRepo_InMemory();

            // Act
            int actualSaved = purchasedCheeseRepo_InMemory.SavePurchasedCheeses(testList);

            // Assert
            int expectedResult = 2;
            Assert.AreEqual(actualSaved, expectedResult);
        }
    }
}