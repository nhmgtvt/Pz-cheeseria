using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Pz.Cheeseria.Api.Business_Logic;
using Pz.Cheeseria.Api.Data;

namespace Pz.Cheeseria.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<ICheeseRepo, CheeseRepo_Static>();
            services.AddSingleton<IPurchasedCheeseRepo, PurchasedCheeseRepo_InMemory>();
            services.AddSingleton<ICheeseDetailService, CheeseDetailService_Static>();
            services.AddSingleton<IPurchasedCheesesService, PurchasedCheesesService_InMemory>();

            services.AddControllers();
            services.AddSwaggerGen();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pz Cheeseria Api V1");
              //  c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pz Cheeseria Api V2");
                c.RoutePrefix = string.Empty;
            });
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
