﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Business_Logic
{
    public class PurchasedCheeseDetail
    {
        public DateTime PurchasedTime { get; set; }
        public int Quantity { get; set; }
        public int CheeseId { get; set; }

        public string CheeseTitle { get; set; }

        public decimal CheesePrice { get; set; }

        public string CheeseDescription { get; set; }

        public string CheeseCategory { get; set; }

        public string CheeseImage { get; set; }
    }
}
