﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Models
{
    /// <summary>
    /// Represents a purchased item
    /// </summary>
    public class PurchasedCheese
    {
        public Guid PurchasedCheeseId { get; set; }
        public DateTime PurchasedTime { get; set; }
        public int CheeseId { get; set; }
        public int Quantity { get; set; }
     }
}
