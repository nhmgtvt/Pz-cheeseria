﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pz.Cheeseria.Api.Business_Logic;
using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetPerchasedCheesesController : Controller
    {
        private readonly IPurchasedCheesesService _service;
        public GetPerchasedCheesesController(IPurchasedCheesesService service)
        {
            _service = service;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ICollection<PurchasedCheeseDetail>))]
        public IActionResult GetPurchasedCheeses()
        {
            GetPurchasedCheesesResult result = _service.GetPurchasedCheeses();
            if (result.Success)
            {
                if (result.PurchasedCheeses != null && result.PurchasedCheeses.Count > 0)
                    return Ok(result.PurchasedCheeses);
                else
                    return NotFound();
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, result.Error);
            }
        }
    }
}
