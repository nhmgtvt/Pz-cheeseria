﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pz.Cheeseria.Api.Business_Logic;
using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CheeseDetailController : Controller
    {
        private readonly ICheeseDetailService _service;
        public CheeseDetailController(ICheeseDetailService service)
        {
            _service = service;
        }
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Cheese))]
        
        public IActionResult GetCheeseDetailById(int id)
        {
            GetCheeseResult result = _service.GetCheeseDetailById(id);
            if (result.Success)
            {
                if (result.Cheese != null)
                    return Ok(result.Cheese);
                else
                    return NotFound();
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, result.Error);
            }
        }
    }
}
