﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pz.Cheeseria.Api.Business_Logic;
using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SavePurchasedCheesesController : Controller
    {
        private readonly IPurchasedCheesesService _service;
        public SavePurchasedCheesesController(IPurchasedCheesesService service)
        {
            _service = service;
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        public IActionResult SavePurchasedCheeses(ICollection<CheeseIdAndQuantity> purchasedIdsAndQuantities)
        {
            SavePurchasedCheesesResult result = _service.SavePurchasedCheeses(purchasedIdsAndQuantities);
            if (result.Success)
            {
                    return Ok(string.Format("{0} Cheeses purchased", result.NumberOfSuccess));
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, result.Error);
            }
        }
    }
}
