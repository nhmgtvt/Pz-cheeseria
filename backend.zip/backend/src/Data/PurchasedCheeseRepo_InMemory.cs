﻿using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Data
{
    public class PurchasedCheeseRepo_InMemory : IPurchasedCheeseRepo
    {
        ICollection<PurchasedCheese> _purchasedCheeses = new List<PurchasedCheese>();
        public ICollection<PurchasedCheese> GetPurchasedCheeses()
        {
            return _purchasedCheeses;
        }

        public int SavePurchasedCheeses(ICollection<PurchasedCheese> purchasedCheeses)
        {
            int success = 0;
            foreach (var purchasedCheese in purchasedCheeses)
            {
                _purchasedCheeses.Add(purchasedCheese);
                success++;
            }
            return success;
        }
    }
}
