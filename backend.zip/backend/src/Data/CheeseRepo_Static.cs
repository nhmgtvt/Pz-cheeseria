﻿using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Data
{
    public class CheeseRepo_Static : ICheeseRepo
    {
        public Cheese GetCheeseById(int Id)
        {
            return CheesesRepository.Cheeses.FirstOrDefault(c => c.Id == Id);
        }
    }
}
