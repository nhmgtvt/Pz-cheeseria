﻿using Pz.Cheeseria.Api.Data;
using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Business_Logic
{
    public class CheeseDetailService_Static : ICheeseDetailService
    {
        private readonly ICheeseRepo _repo;
        public CheeseDetailService_Static(ICheeseRepo repo)
        {
            _repo = repo;
        }
        public GetCheeseResult GetCheeseDetailById(int id)
        {
            var result = new GetCheeseResult();
            try
            {
                var cheese = _repo.GetCheeseById(id);
                result.Cheese = cheese;
            }
            catch (Exception ex) { result.Error = ex.Message; }
            return result;
        }
    }
}
