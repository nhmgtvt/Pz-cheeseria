﻿using Pz.Cheeseria.Api.Data;
using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Business_Logic
{
    public class PurchasedCheesesService_InMemory : IPurchasedCheesesService
    {
        private readonly IPurchasedCheeseRepo _purchasedCheeseRepo;
        private readonly ICheeseRepo _cheeseRepo;
        public PurchasedCheesesService_InMemory(IPurchasedCheeseRepo purchasedCheeseRepo, ICheeseRepo cheeseRepo)
        {
            _cheeseRepo = cheeseRepo;
            _purchasedCheeseRepo = purchasedCheeseRepo;
    }
        public GetPurchasedCheesesResult GetPurchasedCheeses()
        {
            var result = new GetPurchasedCheesesResult();
            try
            {
                var purchasedCheeses = _purchasedCheeseRepo.GetPurchasedCheeses();
                var cheeseDetails = new List<PurchasedCheeseDetail>();
                foreach (var purchasedCheese in purchasedCheeses)
                {
                    var cheeseDetail = _cheeseRepo.GetCheeseById(purchasedCheese.CheeseId);
                    var purchaseCheeseDetail = new PurchasedCheeseDetail();
                    purchaseCheeseDetail.CheeseId = cheeseDetail.Id;
                    purchaseCheeseDetail.CheeseDescription = cheeseDetail.Description;
                    purchaseCheeseDetail.CheeseCategory = cheeseDetail.Category;
                    purchaseCheeseDetail.CheeseImage = cheeseDetail.Image;
                    purchaseCheeseDetail.CheesePrice = cheeseDetail.Price;
                    purchaseCheeseDetail.CheeseTitle = cheeseDetail.Title;
                    purchaseCheeseDetail.PurchasedTime = purchasedCheese.PurchasedTime;
                    purchaseCheeseDetail.Quantity = purchasedCheese.Quantity;
                    cheeseDetails.Add(purchaseCheeseDetail);
                }
            result.PurchasedCheeses = cheeseDetails;
            }
            catch (Exception ex) { result.Error = ex.Message; }
            return result;
        }

        public SavePurchasedCheesesResult SavePurchasedCheeses(ICollection<CheeseIdAndQuantity> purchasedIdsAndQuantities)
        {
            var result = new SavePurchasedCheesesResult();
            //remove duplicate Ids  
            var purchasedIdsQuantities = purchasedIdsAndQuantities.GroupBy(x => x.CheeseId).Select(x => x.First()).ToList();

            try
            {
                var purchasedCheeses = new List<PurchasedCheese>();
                var purchasedTime = DateTime.Now;
                foreach (var idQuantity in purchasedIdsQuantities)
                {
                    int cheeseId = idQuantity.CheeseId;
                    int quantity = idQuantity.Quantity;
                    Cheese cheese = _cheeseRepo.GetCheeseById(cheeseId);
                    // ignore id that maps to no cheese
                    if (cheese == null)
                        continue;

                    var purchasedCheese = new PurchasedCheese();
                    purchasedCheese.PurchasedCheeseId =  Guid.NewGuid();
                    purchasedCheese.CheeseId = cheeseId;
                    purchasedCheese.Quantity = quantity;
                    purchasedCheese.PurchasedTime = purchasedTime;
                    purchasedCheeses.Add(purchasedCheese);
                }
              result.NumberOfSuccess = _purchasedCheeseRepo.SavePurchasedCheeses(purchasedCheeses);
            }
            catch (Exception ex) { result.Error = ex.Message; }
            return result;
        }
    }
}
