﻿using Pz.Cheeseria.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pz.Cheeseria.Api.Business_Logic
{
    public class GetPurchasedCheesesResult : BaseResult
    {
        public ICollection<PurchasedCheeseDetail> PurchasedCheeses { get; set; }
    }
}
